# Dock StandBy mockups

Visual reference for the app (see CLAUDE.md). Open `index.html` in a browser.

| File | Screen |
|---|---|
| `colorful-clock.html` | Colorful · Clock |
| `colorful-charging.html` | Colorful · Charging |
| `colorful-weather-calendar.html` | Colorful · Weather + Calendar |
| `colorful-now-playing.html` | Colorful · Now Playing |
| `colorful-widgets.html` | Colorful · Widget stack |
| `minimal-clock.html` | Minimal · Clock |
| `minimal-charging.html` | Minimal · Charging |
| `minimal-day.html` | Minimal · Day |
| `minimal-analog.html` | Minimal · Analog |
| `night-mode.html` | Night mode |
| `setup.html` | Setup · Theme picker |

Notes for implementation:
- Landscape screens are 844×390 (phone landscape); setup is 390×844 portrait.
- Fonts: Nunito 900 for Colorful numerals, Inter 100–700 elsewhere.
- Text like [Song title] / [Album art] is placeholder for real data.
- Colorful clock palettes: Sunset #FFD60A→#FF7A45→#FF2D92, Ocean #64D2FF→#0A84FF→#5E5CE6,
  Aurora #30D158→#30D5C8→#BF5AF2, Candy #FF9FF3→#BF5AF2→#64D2FF.
- Charging colors by level: <20 #FF2D55/#FF6B2C, <50 #FF9F0A/#FFD60A, else #30D158/#30D5C8.
- Recreate these in Jetpack Compose; CSS animations map to infiniteTransition.
